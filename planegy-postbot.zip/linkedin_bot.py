import openai, os, requests
from datetime import datetime
import random

HASHTAGS = ["#KommunaleWärmeplanung","#DezentraleEnergie","#ESG","#Energieeffizienz","#SmartCity"]

class LinkedInContentAgent:
    def __init__(...):
        ...

    def generate_content(...):
        ...

    def post_to_linkedin(...):
        ...
