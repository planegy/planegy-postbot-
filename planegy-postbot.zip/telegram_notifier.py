import requests, os

def send_telegram(message):
    ...
